let _ = 
	let path = "../../image/lena.png"
	and granularity = string_of_int (10) in 
	let comm = "Python load_img.py " ^ path ^ " " ^ granularity in 
	Sys.command (comm)